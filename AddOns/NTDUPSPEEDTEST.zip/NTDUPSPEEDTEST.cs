#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private ntdupSpeedTest[] cachentdupSpeedTest;

		
		public ntdupSpeedTest ntdupSpeedTest(string accountName, ntdupSpeedTestBT benchCopierBT, bool longName)
		{
			return ntdupSpeedTest(Input, accountName, benchCopierBT, longName);
		}


		
		public ntdupSpeedTest ntdupSpeedTest(ISeries<double> input, string accountName, ntdupSpeedTestBT benchCopierBT, bool longName)
		{
			if (cachentdupSpeedTest != null)
				for (int idx = 0; idx < cachentdupSpeedTest.Length; idx++)
					if (cachentdupSpeedTest[idx].AccountName == accountName && cachentdupSpeedTest[idx].BenchCopierBT == benchCopierBT && cachentdupSpeedTest[idx].LongName == longName && cachentdupSpeedTest[idx].EqualsInput(input))
						return cachentdupSpeedTest[idx];
			return CacheIndicator<ntdupSpeedTest>(new ntdupSpeedTest(){ AccountName = accountName, BenchCopierBT = benchCopierBT, LongName = longName }, input, ref cachentdupSpeedTest);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.ntdupSpeedTest ntdupSpeedTest(string accountName, ntdupSpeedTestBT benchCopierBT, bool longName)
		{
			return indicator.ntdupSpeedTest(Input, accountName, benchCopierBT, longName);
		}


		
		public Indicators.ntdupSpeedTest ntdupSpeedTest(ISeries<double> input , string accountName, ntdupSpeedTestBT benchCopierBT, bool longName)
		{
			return indicator.ntdupSpeedTest(input, accountName, benchCopierBT, longName);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.ntdupSpeedTest ntdupSpeedTest(string accountName, ntdupSpeedTestBT benchCopierBT, bool longName)
		{
			return indicator.ntdupSpeedTest(Input, accountName, benchCopierBT, longName);
		}


		
		public Indicators.ntdupSpeedTest ntdupSpeedTest(ISeries<double> input , string accountName, ntdupSpeedTestBT benchCopierBT, bool longName)
		{
			return indicator.ntdupSpeedTest(input, accountName, benchCopierBT, longName);
		}

	}
}

#endregion
