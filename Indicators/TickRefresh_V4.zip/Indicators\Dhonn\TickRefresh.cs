#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.Dhonn
{
	public class TickRefresh : Indicator
	{
		private long oldTimeFrame;
		private bool isRefreshing;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Refresh the chart on every tick or specified time interval.";
				Name										= "TickRefresh"; // version 4
				Calculate									= Calculate.OnEachTick;
				IsOverlay									= true;
				DisplayInDataBox							= false;
				DrawOnPricePanel							= true;
				IsChartOnly 								= true;
				IsSuspendedWhileInactive					= true;
				RefreshTimeInterval 						= 10; // equal to 100 frames per second
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.Terminated)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			if (isRefreshing || ChartControl == null || State == State.Historical) {
				return;
			}
			if (RefreshTimeInterval > 0) {
				long newTimeFrame = (long)(DateTime.Now.Ticks / (10000*RefreshTimeInterval));
				if (newTimeFrame == oldTimeFrame) {
					return;
				}
				oldTimeFrame = newTimeFrame;
			}
			isRefreshing = true;
			ChartControl.Dispatcher.InvokeAsync(() => {
				ChartControl.InvalidateVisual();
				isRefreshing = false;
			});
		}
		#region Properties
		// copyright Dhonn Lushine
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="Refresh Time Interval in Milliseconds", Description="Number of milliseconds between chart refreshes.\n\n0 will refresh the chart on every tick or price change.\nUnder \"Set up - Calculate\" choose between updates on each tick or price change.\n\nExamples:\n0 = no delay, update immediately on every tick or price change.\n1 = maximum of 1000 updates per second.\n10 = maximum of 100 updates per second.\n20 = maximum of 50 updates per second.\n100 = maximum of 10 updates per second.", Order=1, GroupName="Parameters")]
		public int RefreshTimeInterval
		{ get; set; }
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private Dhonn.TickRefresh[] cacheTickRefresh;
		public Dhonn.TickRefresh TickRefresh(int refreshTimeInterval)
		{
			return TickRefresh(Input, refreshTimeInterval);
		}

		public Dhonn.TickRefresh TickRefresh(ISeries<double> input, int refreshTimeInterval)
		{
			if (cacheTickRefresh != null)
				for (int idx = 0; idx < cacheTickRefresh.Length; idx++)
					if (cacheTickRefresh[idx] != null && cacheTickRefresh[idx].RefreshTimeInterval == refreshTimeInterval && cacheTickRefresh[idx].EqualsInput(input))
						return cacheTickRefresh[idx];
			return CacheIndicator<Dhonn.TickRefresh>(new Dhonn.TickRefresh(){ RefreshTimeInterval = refreshTimeInterval }, input, ref cacheTickRefresh);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.Dhonn.TickRefresh TickRefresh(int refreshTimeInterval)
		{
			return indicator.TickRefresh(Input, refreshTimeInterval);
		}

		public Indicators.Dhonn.TickRefresh TickRefresh(ISeries<double> input , int refreshTimeInterval)
		{
			return indicator.TickRefresh(input, refreshTimeInterval);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.Dhonn.TickRefresh TickRefresh(int refreshTimeInterval)
		{
			return indicator.TickRefresh(Input, refreshTimeInterval);
		}

		public Indicators.Dhonn.TickRefresh TickRefresh(ISeries<double> input , int refreshTimeInterval)
		{
			return indicator.TickRefresh(input, refreshTimeInterval);
		}
	}
}

#endregion
