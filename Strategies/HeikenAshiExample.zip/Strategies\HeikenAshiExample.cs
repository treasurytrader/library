#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class HeikenAshiExample : Strategy
	{
		private HeikenAshi8 myH8;
		private EMA myEMA;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "HeikenAshiExample";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				AddPlot(Brushes.DodgerBlue, "EMAPlot");
			}
			else if (State == State.DataLoaded)
			{
				myH8 = HeikenAshi8();			// Crete private instance of indicator
				myEMA = EMA(myH8.HAClose, 30);	// create private instance of EMA with Heiken-ashi close as the input
				AddChartIndicator(myH8);  		// to display the heiken ashi on the chart bars
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < 20) return;
			
			EMAPlot[0] = myEMA[0];  		// plot the ema based on heiken ashi which will be applied to the Unirenko chart bars
			
			
			if (myH8.HAHigh[0] > myEMA[0] && myH8.HAHigh[1] < myEMA[1])  // cross condition example
			{
				Draw.VerticalLine(this, "test"+CurrentBar, 0, Brushes.Gold); // to verify on chart
			}
			
			
		}

		#region Properties

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> EMAPlot
		{
			get { return Values[0]; }
		}
		#endregion

	}
}
